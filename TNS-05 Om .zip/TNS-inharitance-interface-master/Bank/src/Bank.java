
public interface Bank {
	int noOfaccount=0;
	void deposit(Account ac,int amount);
	void widraw(Account ac,int amount);

}
