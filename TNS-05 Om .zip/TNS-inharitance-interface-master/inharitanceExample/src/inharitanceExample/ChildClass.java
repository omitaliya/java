package inharitanceExample;

public class ChildClass extends ParentClass {

}
