package inharitanceExample;

public class DemoMain {

	public static void main(String[] args) {
		ChildClass cc=new ChildClass();
		cc.setMarks(15);
		System.out.println(cc);

	}

}
