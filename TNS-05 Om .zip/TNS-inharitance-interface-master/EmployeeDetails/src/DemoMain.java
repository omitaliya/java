
public class DemoMain {

	public static void main(String[] args) {
		Employee ep=new Employee("abc","rahul","abc",21,12456,1200);
		System.out.println(ep);
		Manager mp=new Manager("xyz","ravi","idk",22,156345,1500);
		System.out.println(mp);

	}

}
