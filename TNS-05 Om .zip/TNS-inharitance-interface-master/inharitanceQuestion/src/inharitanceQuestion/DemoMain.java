package inharitanceQuestion;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square sc=new Square(5);
		sc.area();
		sc.parameter();


	}

}
