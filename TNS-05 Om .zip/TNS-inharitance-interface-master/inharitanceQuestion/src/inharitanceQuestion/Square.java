package inharitanceQuestion;

public class Square extends Rectangle{
	

	public Square(int l) {
		
		super(l,l);
	}
	
	
	
	

}
